<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora de Reajuste</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: white;
        }
        .container {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            max-width: 400px;
            width: 100%;
        }
        h1 {
            margin-bottom: 20px;
            color: #333;
        }
        form {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            text-align: left;
        }
        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            padding: 10px 20px;
            background-color: #007BFF;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }
        button:hover {
            background-color: #0056b3;
        }
        section {
            margin-top: 20px;
            text-align: left;
        }
        p {
            margin: 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Calculadora de Reajuste</h1>

        <form method="POST">
            <label for="preco">Preço Atual (R$):</label>
            <input type="number" step="0.01" name="preco" id="preco" required>

            <label for="reaj">Percentual de Reajuste (%):</label>
            <input type="number" step="0.01" name="reaj" id="reaj" required>

            <button type="submit">Calcular</button>
        </form>

        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $preco = isset($_POST['preco']) ? (float)$_POST['preco'] : 0;
            $reaj = isset($_POST['reaj']) ? (float)$_POST['reaj'] : 0;

            $aumento = $preco * $reaj / 100;
            $novo = $preco + $aumento;
        ?>
            <section>
                <h2>Resultado do Reajuste</h2>
                <p>
                    O produto que custava R$<?= number_format($preco, 2, ",", ".") ?>, 
                    com <strong><?= $reaj ?>%</strong> de aumento, 
                    vai passar a custar <strong>R$<?= number_format($novo, 2, ",", ".") ?></strong> 
                    a partir de agora.
                </p>
            </section>
        <?php
        }
        ?>
    </div>
</body>
</html>